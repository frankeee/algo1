#include "../baldosasDelPiso.h"
#include "gtest/gtest.h"

// Escribir tests aca:
