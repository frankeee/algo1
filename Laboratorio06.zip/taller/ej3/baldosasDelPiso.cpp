int baldosasDelPiso(int M, int N, int B) {
	return 0;
	// Borrar el return dummy y completar
}
