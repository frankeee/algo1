bool esPrimo(int n);
